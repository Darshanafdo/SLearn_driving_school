<?php

if (isset($_POST['Login'])) {

    $email = $_POST['Email'];
    $password = $_POST['Password'];
}

// function eka login ake 

$query = "SELECT * FROM  login WHERE Email,Password * "

?>;